
$l2h_cache_key = q/in block/;
$l2h_cache{$l2h_cache_key} = q|in block|;

$l2h_cache_key = q/Surrounded by empty lines./;
$l2h_cache{$l2h_cache_key} = q|Surrounded by empty lines.|;
1;