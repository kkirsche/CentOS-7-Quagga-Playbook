
$l2h_cache_key = q/$--a@minus{} {\frac{1}{2}}$/;
$l2h_cache{$l2h_cache_key} = q|<!-- MATH
 $- -a@minus{} {\frac{1}{2}}$
 -->
<SPAN CLASS="MATH"><IMG
 WIDTH="100" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="sing_3.png"
 ALT="$--a@minus{} {\frac{1}{2}}$"></SPAN>|;

$l2h_cache_key = q/$$\partial_t \eta (t) = g(\eta(t),\varphi(t))$$ ''/;
$l2h_cache{$l2h_cache_key} = q|<BR><P></P>
<DIV ALIGN="CENTER" CLASS="mathdisplay">
<!-- MATH
 \begin{displaymath}
\partial_t \eta (t) = g(\eta(t),\varphi(t))
\end{displaymath}
 -->

<IMG
 WIDTH="100" HEIGHT="20" BORDER="0"
 SRC="sing_1.png"
 ALT="\begin{displaymath}\partial_t \eta (t) = g(\eta(t),\varphi(t))\end{displaymath}">
</DIV>
<BR CLEAR="ALL">
<P></P> ''|;

$l2h_cache_key = q/$--a {\frac{1}{2}} @minus{}$/;
$l2h_cache{$l2h_cache_key} = q|<!-- MATH
 $- -a {\frac{1}{2}} @minus{}$
 -->
<SPAN CLASS="MATH"><IMG
 WIDTH="100" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="sing_2.png"
 ALT="$--a {\frac{1}{2}} @minus{}$"></SPAN>|;
1;